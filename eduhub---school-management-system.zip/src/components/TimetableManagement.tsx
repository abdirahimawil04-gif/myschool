import React, { useState } from 'react';
import { useFirestoreCollection } from '../lib/useFirestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { useAuth } from '../lib/AuthContext';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar, Clock, Plus, BookOpen, User } from 'lucide-react';
import { toast } from 'sonner';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const TIME_SLOTS = [
  '08:00 AM - 09:00 AM',
  '09:00 AM - 10:00 AM',
  '10:00 AM - 11:00 AM',
  '11:00 AM - 12:00 PM',
  '12:00 PM - 01:00 PM',
  '01:00 PM - 02:00 PM',
  '02:00 PM - 03:00 PM',
];

export default function TimetableManagement() {
  const { profile } = useAuth();
  const { data: classes } = useFirestoreCollection<any>('classes');
  const [selectedClass, setSelectedClass] = useState<string>('');

  // Mock timetable data for visualization
  const mockTimetable: Record<string, Record<string, any>> = {
    'Monday': {
      '08:00 AM - 09:00 AM': { subject: 'Mathematics', teacher: 'Mr. Smith' },
      '09:00 AM - 10:00 AM': { subject: 'Physics', teacher: 'Mrs. Johnson' },
    },
    'Tuesday': {
      '10:00 AM - 11:00 AM': { subject: 'English', teacher: 'Ms. Davis' },
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Academic Timetable</h1>
          <p className="text-slate-500 mt-1">Schedule and view class timings and subject assignments.</p>
        </div>
        
        <Button className="bg-indigo-600 hover:bg-indigo-700 gap-2">
          <Plus size={18} />
          Add Schedule
        </Button>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-bold flex items-center gap-2">
              <Calendar className="w-5 h-5 text-indigo-600" />
              Weekly Schedule
            </CardTitle>
            <div className="w-64">
              <Select onValueChange={setSelectedClass}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Class" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map((cls: any) => (
                    <SelectItem key={cls.id} value={cls.id}>{cls.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <Table>
            <TableHeader className="bg-slate-50">
              <TableRow>
                <TableHead className="w-[200px] border-r border-slate-100 font-bold">Time Slot</TableHead>
                {DAYS.map(day => (
                  <TableHead key={day} className="min-w-[150px] font-bold text-center">{day}</TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {TIME_SLOTS.map(slot => (
                <TableRow key={slot} className="h-24">
                  <TableCell className="font-medium text-slate-500 border-r border-slate-100 flex items-center gap-2">
                    <Clock size={14} />
                    {slot}
                  </TableCell>
                  {DAYS.map(day => {
                    const entry = mockTimetable[day]?.[slot];
                    return (
                      <TableCell key={`${day}-${slot}`} className="p-2 border-r border-slate-50 last:border-r-0">
                        {entry ? (
                          <div className="h-full w-full bg-indigo-50 rounded-lg p-3 border border-indigo-100 flex flex-col justify-center">
                            <div className="flex items-center gap-1 text-indigo-700 font-bold text-sm mb-1">
                              <BookOpen size={12} />
                              {entry.subject}
                            </div>
                            <div className="flex items-center gap-1 text-slate-500 text-xs">
                              <User size={10} />
                              {entry.teacher}
                            </div>
                          </div>
                        ) : (
                          <div className="h-full w-full flex items-center justify-center text-slate-300 italic text-xs">
                            No Class
                          </div>
                        )}
                      </TableCell>
                    );
                  })}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
