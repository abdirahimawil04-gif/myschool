import React, { useState } from 'react';
import { useFirestoreCollection } from '../lib/useFirestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { useAuth } from '../lib/AuthContext';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  DollarSign, 
  Plus, 
  Search, 
  TrendingUp, 
  TrendingDown, 
  CreditCard,
  Download
} from 'lucide-react';
import { toast } from 'sonner';

interface FeeRecord {
  id: string;
  studentId: string;
  studentName: string;
  amount: number;
  type: string;
  status: 'paid' | 'pending' | 'overdue';
  dueDate: string;
}

export default function FinanceManagement() {
  const { profile } = useAuth();
  const { data: fees, loading } = useFirestoreCollection<FeeRecord>('fees');
  const [searchTerm, setSearchTerm] = useState('');

  const stats = [
    { label: 'Total Revenue', value: '$45,200', icon: <TrendingUp className="text-green-600" />, color: 'bg-green-50' },
    { label: 'Pending Fees', value: '$12,400', icon: <TrendingDown className="text-red-600" />, color: 'bg-red-50' },
    { label: 'Collected Today', value: '$3,150', icon: <DollarSign className="text-blue-600" />, color: 'bg-blue-50' },
    { label: 'Active Invoices', value: '124', icon: <CreditCard className="text-purple-600" />, color: 'bg-purple-50' },
  ];

  const filteredFees = fees.filter(fee => 
    fee.studentName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    fee.type?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Finance Management</h1>
          <p className="text-slate-500 mt-1">Track fee collection, invoices, and school expenses.</p>
        </div>
        
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2">
            <Download size={18} />
            Export Report
          </Button>
          <Button className="bg-indigo-600 hover:bg-indigo-700 gap-2">
            <Plus size={18} />
            Create Invoice
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <Card key={i} className="border-none shadow-sm group hover:shadow-md transition-all">
            <CardContent className="p-6 flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium text-slate-500">{stat.label}</p>
                <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
              </div>
              <div className={`p-3 rounded-xl ${stat.color} transition-transform group-hover:scale-110`}>
                {stat.icon}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-slate-900">Recent Transactions</h2>
          <div className="flex items-center gap-2 bg-white px-3 py-1 rounded-lg border border-slate-200 shadow-sm w-64">
            <Search className="text-slate-400" size={18} />
            <Input 
              placeholder="Search transactions..." 
              className="border-none h-8 focus-visible:ring-0 text-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <Table>
            <TableHeader className="bg-slate-50">
              <TableRow>
                <TableHead className="font-bold">Student</TableHead>
                <TableHead className="font-bold">Fee Type</TableHead>
                <TableHead className="font-bold">Amount</TableHead>
                <TableHead className="font-bold">Due Date</TableHead>
                <TableHead className="font-bold">Status</TableHead>
                <TableHead className="text-right font-bold">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-10 text-slate-500">Loading transactions...</TableCell>
                </TableRow>
              ) : filteredFees.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-10 text-slate-500">
                    <div className="flex flex-col items-center gap-2">
                      <DollarSign size={40} className="text-slate-200" />
                      <span>No transactions found.</span>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filteredFees.map((fee) => (
                  <TableRow key={fee.id} className="hover:bg-slate-50/50 transition-colors">
                    <TableCell className="font-semibold">{fee.studentName}</TableCell>
                    <TableCell>{fee.type}</TableCell>
                    <TableCell className="font-bold text-slate-900">${fee.amount}</TableCell>
                    <TableCell className="text-slate-500">{fee.dueDate}</TableCell>
                    <TableCell>
                      <Badge 
                        variant={fee.status === 'paid' ? 'default' : fee.status === 'pending' ? 'secondary' : 'destructive'}
                        className={fee.status === 'paid' ? 'bg-green-100 text-green-700 hover:bg-green-100' : ''}
                      >
                        {fee.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" className="text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50">View Invoice</Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
