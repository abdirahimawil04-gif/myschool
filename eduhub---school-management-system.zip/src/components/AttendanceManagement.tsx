import React, { useState } from 'react';
import { useFirestoreCollection } from '../lib/useFirestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, addDoc, serverTimestamp, query, where, getDocs } from 'firebase/firestore';
import { useAuth } from '../lib/AuthContext';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from '@/components/ui/badge';
import { ClipboardList, Check, X, Clock, Save } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function AttendanceManagement() {
  const { profile } = useAuth();
  const { data: classes } = useFirestoreCollection<any>('classes');
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [students, setStudents] = useState<any[]>([]);
  const [attendance, setAttendance] = useState<Record<string, 'present' | 'absent' | 'late'>>({});
  const [loading, setLoading] = useState(false);

  const fetchStudents = async (classId: string) => {
    setLoading(true);
    try {
      const q = query(collection(db, 'students'), where('classId', '==', classId));
      const querySnapshot = await getDocs(q);
      const studentList = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setStudents(studentList);
      
      // Initialize attendance state
      const initialAttendance: Record<string, 'present' | 'absent' | 'late'> = {};
      studentList.forEach(s => initialAttendance[s.id] = 'present');
      setAttendance(initialAttendance);
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, 'students');
    } finally {
      setLoading(false);
    }
  };

  const handleClassChange = (value: string) => {
    setSelectedClass(value);
    fetchStudents(value);
  };

  const handleStatusChange = (studentId: string, status: 'present' | 'absent' | 'late') => {
    setAttendance(prev => ({ ...prev, [studentId]: status }));
  };

  const saveAttendance = async () => {
    if (!selectedClass) return;
    setLoading(true);
    try {
      const today = format(new Date(), 'yyyy-MM-dd');
      const batch = Object.entries(attendance).map(([studentId, status]) => {
        return addDoc(collection(db, 'attendance'), {
          studentId,
          classId: selectedClass,
          date: today,
          status,
          recordedBy: profile?.uid,
          schoolId: profile?.schoolId || 'default_school',
          createdAt: serverTimestamp(),
        });
      });
      await Promise.all(batch);
      toast.success("Attendance saved successfully for today");
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'attendance');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Attendance</h1>
          <p className="text-slate-500 mt-1">Mark daily attendance for students.</p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-lg border border-slate-200 shadow-sm">
            <span className="text-sm font-medium text-slate-500">Date:</span>
            <span className="text-sm font-bold text-indigo-600">{format(new Date(), 'PPP')}</span>
          </div>
          <Button 
            onClick={saveAttendance} 
            disabled={!selectedClass || students.length === 0 || loading}
            className="bg-indigo-600 hover:bg-indigo-700 gap-2"
          >
            <Save size={18} />
            Save Attendance
          </Button>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-6">
        <div className="max-w-xs space-y-2">
          <label className="text-sm font-medium text-slate-700">Select Class</label>
          <Select onValueChange={handleClassChange}>
            <SelectTrigger>
              <SelectValue placeholder="Choose a class..." />
            </SelectTrigger>
            <SelectContent>
              {classes.map((cls: any) => (
                <SelectItem key={cls.id} value={cls.id}>{cls.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedClass && (
          <div className="rounded-lg border border-slate-100 overflow-hidden">
            <Table>
              <TableHeader className="bg-slate-50">
                <TableRow>
                  <TableHead className="w-[100px]">Adm #</TableHead>
                  <TableHead>Student Name</TableHead>
                  <TableHead className="text-center">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center py-10">Loading students...</TableCell>
                  </TableRow>
                ) : students.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={3} className="text-center py-10">No students found in this class.</TableCell>
                  </TableRow>
                ) : (
                  students.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell className="font-medium text-slate-500">{student.admissionNumber}</TableCell>
                      <TableCell className="font-semibold">{student.displayName}</TableCell>
                      <TableCell>
                        <div className="flex justify-center gap-2">
                          <Button 
                            variant={attendance[student.id] === 'present' ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => handleStatusChange(student.id, 'present')}
                            className={attendance[student.id] === 'present' ? 'bg-green-600 hover:bg-green-700' : 'hover:bg-green-50 hover:text-green-600'}
                          >
                            <Check size={16} className="mr-1" /> Present
                          </Button>
                          <Button 
                            variant={attendance[student.id] === 'absent' ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => handleStatusChange(student.id, 'absent')}
                            className={attendance[student.id] === 'absent' ? 'bg-red-600 hover:bg-red-700' : 'hover:bg-red-50 hover:text-red-600'}
                          >
                            <X size={16} className="mr-1" /> Absent
                          </Button>
                          <Button 
                            variant={attendance[student.id] === 'late' ? 'default' : 'outline'}
                            size="sm"
                            onClick={() => handleStatusChange(student.id, 'late')}
                            className={attendance[attendance[student.id] === 'late' ? 'bg-orange-600 hover:bg-orange-700' : 'hover:bg-orange-50 hover:text-orange-600']}
                          >
                            <Clock size={16} className="mr-1" /> Late
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </div>
  );
}
